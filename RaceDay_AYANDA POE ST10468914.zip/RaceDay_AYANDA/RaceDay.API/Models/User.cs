﻿namespace RaceDay.API.Models
{
    public class User
    {
        public int UserID { get; set; }
        public string FirstName { get; set; } = "";
        public string LastName { get; set; } = "";
        public string Email { get; set; } = "";
        public string PasswordHash { get; set; } = "";
        public string PhoneNumber { get; set; } = "";
        public string Role { get; set; } = "";
        public DateTime DateRegistered { get; set; }

        // Participant profile picture stored in Azure Blob Storage
        public string? ProfilePictureUrl { get; set; }
    }
}
